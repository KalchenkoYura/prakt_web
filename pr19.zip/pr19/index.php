﻿<?php
session_start();

error_reporting(0);

if($_SESSION['register'])
{
	header("Location: lk.php");
}

if($_SESSION['htmlhack'] || $_SESSION['sqlhack'])
{
	include "block.php";
}
?>
<!DOCTYPE html>
<html>
	<header>
		<link href="css.css" rel="stylesheet" type="text/css" />
	</header>
	<body>
		<form action="send.php" method="post" enctype="multipart/form-data">
			<section>
				<h4>Регистрация</h4>
				<hr size="1" noshade>
			</section>
			<input autocomplete="off" type='text' size="19" pattern="[A-Za-zА-Яа-яЁё]{2,10}" placeholder="Имя" name="name" required ><br>
			<input autocomplete="on" type='text' size="19" placeholder="Фамилия" name="surname" pattern="[A-Za-zА-Яа-яЁё]{2,14}" required >
			<p>Пол:
				<input type="radio" name="sex" value="man" checked>
				<label for="sex">муж</label>
				<input type="radio" name="sex" value="female" checked>
				<label for="sex">жен</label>
			</p>
			<input autocomplete="on" size="19" type='text' min="0" placeholder="Ваш возраст" pattern="^[ 0-9]+$"name="age"><br>
			<input autocomplete="on" type='email' size="19" placeholder="Ваш email" name="email" pattern="[A-Za-zА-Яа-яЁё]{4,}+$" required ><br>
			<input autocomplete="on" type='text' size="19" placeholder="Ваш логин" name="login" required ><br>
			<input autocomplete="off" type='password' size="19" placeholder="password" name="password" required pattern="((?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,})" maxlength="14"><br>
			<input type="file" name="avatar" accept="image/*"><br>
			<button type='submit' name="sub" size="19" >Зарегистрироваться</button>
			<p>Уже зерегистрированны?<a href="login.html">Войти</a></p>
		</form>
	</body>
</html>