<?php
session_start();

error_reporting(0);

$login = $_SESSION['login'];

if(!$_SESSION['register'])
{
    header("Location: index.php");
}

if($_SESSION['htmlhack'])
{
    include "block.php";
}

include "connectdb.php";

$recived = $connect->query("SELECT * FROM prac16 WHERE login= '$login';");

$data = $recived->fetch_assoc();

$id = $data['id'];

$_SESSION['timeout'] = date('i');
?>

<!DOCTYPE html>
<html lang="ru">
	<header>
		<link href="css.css" rel="stylesheet" type="text/css" />
	</header>
	<body>
		<form action="send.php" method="post" enctype="multipart/form-data">
			<section>
				<h4>Пользователь</h4>
				<hr size="1" noshade>
			</section>
			<img src="<?=$data['avatar']?>"><br>
			<input autocomplete="off" type='text' size="19" placeholder="Имя" name="name" value="<?=$data['name']?>" required ><br>
			<input autocomplete="on" type='text' size="19" placeholder="Фамилия" name="surname" value="<?=$data['surname']?>" required >
			<p>
				Пол:
				<input autocomplete="on" type='radio' size="9" name="man" value="<?=$data['man']?>">муж
				<input autocomplete="on" type='radio' name="female"  value="<?=$data['female']?>">жен
			</p>
			<input autocomplete="on" size="19" type='text' min="0" placeholder="Ваш возраст" name="age" value="<?=$data['age']?>"><br>
			<input autocomplete="on" type='email' size="19" placeholder="Ваш email" name="email" required value="<?=$data['email']?>"><br>
			<input autocomplete="on" type='text' size="19" placeholder="Ваш логин" name="login" required value="<?=$data['login']?>"><br>
			<a href="logout.php">Выйти</a>
		</form>
	</body>
</html>