-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Апр 14 2017 г., 22:42
-- Версия сервера: 10.1.21-MariaDB
-- Версия PHP: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `prac16`
--

-- --------------------------------------------------------

--
-- Структура таблицы `prac16`
--

CREATE TABLE `prac16` (
  `id` int(11) NOT NULL,
  `name` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `surname` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `sex` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `age` int(11) NOT NULL,
  `email` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `login` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `password` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `avatar` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `prac16`
--

INSERT INTO `prac16` (`id`, `name`, `surname`, `sex`, `age`, `email`, `login`, `password`, `avatar`) VALUES
(1, 'Yura', 'Kalchenko', 'man', 18, 'yura.kalchenko@mail.ru', 'Admin', 'aA123456', 'image/aPe9VNy1Pfphoto_2015-06-22_19-39-35.jpg'),
(2, 'Yura', 'Kalchenko', 'man', 18, 'yura.kalchenko@mail.ru', 'Kalchenko', 'bb2328a15df0a4a464ced82fef62fd0439d605be', 'image/IZY3512axXEc85cXvRw68.jpg');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `prac16`
--
ALTER TABLE `prac16`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `prac16`
--
ALTER TABLE `prac16`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
