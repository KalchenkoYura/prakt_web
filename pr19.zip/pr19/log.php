<?php

if (!empty($_POST['login'])) {
    $login = $_POST['login'];
} else {
    die("<center>Пустое поле логина</center>");
}

$connect = new mysqli('localhost', 'root', '', 'prac16');

$rec = $connect->query("SELECT id FROM prac16 WHERE login = '$login'");

$dat=$rec->fetch_assoc();

$id = $dat['id'];

$salt=pow((int)$id, 3);

if (!empty($_POST['password'])) {
    $password = sha1(sha1($_POST['password'].$salt));
} else {
    die("<center>Пустое поле пароля");
}

$connect->set_charset('utf8');

$recived = $connect->query("SELECT login FROM prac16 WHERE login = '$login' and password='$password';");

$data = $recived->fetch_assoc();

if($data['login'] == $login)
{
    $recived = $connect->query("SELECT password FROM prac16 WHERE login= '$login';");
    $data = $recived->fetch_assoc();
    if($data['password'] == $password)
    {
        echo "<script>alert('Вы успешно залогинились под ником: $login');</script>";
        include "lk.php";
    } else {
        die("<center>Неверный пароль</center>");
    }
}else{
    die("<center>Пользователя с таким логином не существует!</center>");
};
?>