<?php
header('Content-Type: text/html; charset=utf-8');

function genPass($length){
  $chars = 'abcdefghiklmnopqrstvxyzABCDEFGHIKLMNOPQRSTVXYZ1234567890';
  $numChars = strlen($chars);
  $string = '';
  for ($i = 0; $i < $length; $i++) {
    $string .= substr($chars, rand(1, $numChars) - 1, 1);
  }
  return $string;
}

$fname = $_FILES['avatar']['name'];
$types     = array(
	'.jpg',
	'.JPG',
	'.jpeg',
	'.bmp',
	'.png'
    );
$ext = substr($fname, strpos($fname, '.'), strlen($fname) - 1); 
$basepath = "image/";

if (!in_array($ext, $types)) {
	die('<p style="color:red;">Загружаемый файл не является картинкой</p>');
}



$fname = genPass(10) . $fname;

$avatar = $basepath . $fname;

move_uploaded_file($_FILES['avatar']['tmp_name'], $avatar);

if(!empty($_POST['name']))
	$name=$_POST['name'];
else
	die("Вы забыли ввести имя");

if (!preg_match("/[A-Za-zА-Яа-яЁё]{2,10}\)+$/", $name)) 
{
	$name=$_POST['name'];
}
else{
	die("Данные в поле Имя введены не правильно!!!");
}

if(!empty($_POST['surname']))
	$surname=$_POST['surname'];
else
	die("Вы забыли ввести фамилию");

if (!preg_match("/[A-Za-zА-Яа-яЁё]{2,14}\)+$/", $surname)) 
{
	$surname=$_POST['surname'];
}
else{
	die("Данные в поле Фамиллия введены не правильно!!!");
}

if(!is_null($_POST['sex']))
	$sex=$_POST['sex'];
else
	$sex='undefined';

if(!empty($_POST['age']))
	$age=$_POST['age'];
else
	die("Вы забыли ввести возраст");

if (!preg_match("/^[0-9]+$\)+$/", $age)) 
{
	$age=$_POST['age'];
}
else{
	die("Данные в поле Возраст введены не правильно!!!");
}

if(!empty($_POST['email']))
	$email=$_POST['email'];
else
	die("Вы забыли ввести email");

if(!empty($_POST['login']))
	$login=$_POST['login'];
else
	die("Вы забыли ввести логин");

if (preg_match("/[A-Za-zА-Яа-яЁё]{4,}+$/", $login))
{
	$login=$_POST['login'];
}
else{
	die("<br/> Данные в поле Логин введены не правильно!!!");
}

include "connectdb.php";

$connect = new mysqli('localhost', 'root', '', 'prac16');

$rec = $connect->query("SELECT id FROM prac16 ORDER BY id DESC LIMIT 1");

$data=$rec->fetch_assoc();

$id = $data['id'] + 1;

$salt=pow((int)$id, 3);

if(!empty($_POST['password']))
	$password=$_POST['password'];
else
	die("Вы забыли ввести пароль");

if (!preg_match("/(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}\)+$/", $password)) 
{
	$password=sha1(sha1($_POST['password'].$salt));
}
else{
	die("Данные в поле Пароль введены не правильно!!!");
}

$log->query("SELECT COUNT(login) FROM prac16 WHERE login='$login';")

if($log>0)
{
	die("Такой логин уже есть!");
}

$connect->query("INSERT INTO prac16 VALUES ('','$name', '$surname', '$sex', '$age', '$email', '$login', '$password', '$avatar');");

if (mysqli_connect_error()) {
	die('Ошибка подключения (' . mysqli_connect_errno() . ') '. mysqli_connect_error());
} else {include "index.html"; echo "<script>alert('".$name." Вы зарегестрированы');</script>";}

$connect->close();