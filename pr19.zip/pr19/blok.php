<?php
error_reporting(0);
$_SESSION['elapsedTime'] = date("i") - $_SESSION['timeout'];
$timeout = $_SESSION['elapsedTime'] - date("i");

$_SESSION['register'] = false;

if($_SESSION['htmlhack'] && $_SESSION['elapsedTime'] < 3)
{
	if($_SESSION['elapsedTime'] > 3)
	{
		unset($_SESSION);
		session_destroy();
	}
	$time = $_SESSION['elapsedTime'];
	die("Доступ к сайту закрыт на 3 минуты <br>Прошло: $time мин.");
}

if($_SESSION['sqlhack'] && $_SESSION['elapsedTime'] < 5)
{
    if($_SESSION['elapsedTime'] > 5)
    {
        unset($_SESSION);
        session_destroy();
    }
    $time = $_SESSION['elapsedTime'];
    die("Доступ к сайту закрыт на 5 минут <br>Прошло: $time мин.");
}