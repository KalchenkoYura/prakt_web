<?php
header('Content-Type: text/html; charset=utf-8');
if(isset($_POST['name']))
	$name=$_POST['name'];
else
	die("Вы забыли ввести имя");

if(isset($_POST['surname']))
	$surname=$_POST['surname'];
else
	die("Вы забыли ввести фамилию");

if(isset($_POST['man']))
	$sex="man";
else
	if(isset($_POST['female']))
		$sex="female";
	else
		die("Вы забыли ввести пол");

if(isset($_POST['age']))
	$age=$_POST['age'];
else
	die("Вы забыли ввести возраст");

if(isset($_POST['email']))
	$email=$_POST['email'];
else
	die("Вы забыли ввести email");

if(isset($_POST['login']))
	$login=$_POST['login'];
else
	die("Вы забыли ввести логин");

if(isset($_POST['pass']))
	$pass=$_POST['pass'];
else
	die("Вы забыли ввести пароль");

$connect = new mysqli('localhost', 'root', '', 'prakt4');

$connect->set_charset('utf8');

$connect->query("INSERT INTO prakt4 VALUES ('$name', '$surname', '$sex', '$age', '$email', '$login', '$pass');");

if (mysqli_connect_error()) {
	die('Ошибка подключения (' . mysqli_connect_errno() . ') '. mysqli_connect_error());
} else {echo $name . " Вы зарегестрированы";}

$connect->close();