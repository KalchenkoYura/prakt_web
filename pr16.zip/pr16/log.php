<?php
if(isset($_POST['login']))
	$login=$_POST['login'];
else
	die("Вы забыли ввести логин");

if(isset($_POST['pass']))
	$pass=$_POST['pass'];
else
	die("Вы забыли ввести пароль");

$connect = new mysqli('localhost', 'root', '', 'prakt4');

$connect->set_charset('utf8');

$rec = $connect->query("SELECT * FROM prakt4 WHERE login = '".$login."';");

$data = $rec->fetch_assoc();

if($data['login'] == $login)
{
	$connect->query("SELECT * FROM prakt4 WHERE login = '".$login."', password ='".$pass."';");
    echo "Вы успешно залогинились под ником: ". $login;
}
else
{
    die("Наверное вы чтото ввели не правильно или не существует такого пользователь");
};

$connect->close();