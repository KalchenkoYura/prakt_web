function generateColor()
{
	return '#' + Math.floor(Math.random() * 16777215).toString(16)
};

function hide(el) 
{
    if (!el.hasAttribute('displayOld')) 
    {
        el.setAttribute("displayOld", el.style.display)
    }
	el.style.display = "none"
}

function show(el) {
    var old = el.getAttribute("displayOld");
	el.style.display = old || "";
}

function colorsFirst () 
{
	hide(s2);
	hide(s3);
	hide(s4);
	hide(d1);
	hide(l1);
	document.getElementById("h1").style.color=generateColor();
	document.getElementById("p1").style.color=generateColor();
	document.getElementById("h1").style.fontSize='68px';
	document.getElementById("p1").style.fontSize='60px';
	document.getElementById("h1").style.left='400px';
	document.getElementById("p1").style.left='10px';
	document.getElementById("p1").style.width='1603px';
	document.getElementById("s1").style.textAligin='justify';
	document.getElementById("s1").style.top='400px';	
	document.getElementById("sec3").style.top='1596px';	
	document.getElementById("sec4").style.top='2024px';	
	document.getElementById("sec5").style.top='2844px';	
	document.getElementById("sec6").style.top='3424px';	
	document.getElementById("sec7").style.top='3780px';	
	document.getElementById("sec8").style.top='4040px';	
	document.getElementById("fo").style.top='4220px';

}

function endFirst()
{
	document.getElementById("h1").style.color="black";
	document.getElementById("p1").style.color="rgb(132, 132, 132)";
	show(s2);
	show(s3);
	show(s4);
	show(d1);
	show(l1);
	document.getElementById("h1").style.fontSize='24px';
	document.getElementById("p1").style.fontSize='16px';
	document.getElementById("s1").style.textAligin='center';
	document.getElementById("h1").style.left='270.937px';
	document.getElementById("p1").style.left='272.002px';
	document.getElementById("p1").style.width='295px';
	document.getElementById("s1").style.top='0px';	
	document.getElementById("sec3").style.top='1196px';	
	document.getElementById("sec4").style.top='1624px';	
	document.getElementById("sec5").style.top='2444px';	
	document.getElementById("sec6").style.top='3024px';	
	document.getElementById("sec7").style.top='3380px';	
	document.getElementById("sec8").style.top='3640px';	
	document.getElementById("fo").style.top='3820px';
}

function colorsSecond () 
{
	document.getElementById("h2").style.color=generateColor();
	document.getElementById("p2").style.color=generateColor();
	hide(s1);
	hide(s3);
	hide(s4);
}

function endSecond()
{
	document.getElementById("h2").style.color="black";
	document.getElementById("p2").style.color="rgb(132, 132, 132)";
	show(s1);
	show(s3);
	show(s4);
}

function colorsThird () 
{
	document.getElementById("h3").style.color=generateColor();
	document.getElementById("p3").style.color=generateColor();
	hide(s1);
	hide(s2);
	hide(s4);
}

function endThird ()
{
	document.getElementById("h3").style.color="black";
	document.getElementById("p3").style.color="rgb(132, 132, 132)";
	show(s1);
	show(s2);
	show(s4);
}

function colorsFourth () 
{
	document.getElementById("h4").style.color=generateColor();
	document.getElementById("p4").style.color=generateColor();
	hide(s1);
	hide(s2);
	hide(s3);
}

function endFourth()
{
	document.getElementById("h4").style.color="black";
	document.getElementById("p4").style.color="rgb(132, 132, 132)";
	show(s1);
	show(s2);
	show(s3);
}

function videoFirst()
{
	document.getElementById("video").src='https://www.youtube.com/embed/R0HkxQWSkBY?autoplay=1';
}

function videoSecond()
{
	document.getElementById("video").src='https://www.youtube.com/embed/3io3-R-Vc1E?autoplay=1';
}