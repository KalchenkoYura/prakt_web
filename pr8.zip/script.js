let counter = 2;

function isInteger(num) {
  return (num ^ 0) === num;
}

function hide(el) 
{
    if (!el.hasAttribute('displayOld')) 
    {
        el.setAttribute("displayOld", el.style.display)
    }
	el.style.display = "none"
}

function show(el) {
    var old = el.getAttribute("displayOld");
	el.style.display = old || "";
}

function hideh(el)
{
	if (!el.hasAttribute('displayOld')) 
	{
		el.setAttribute("displayOld",el.style.background)
	}
	el.style.background= "none"
}

function showS(el) {
    el.style.background = "url('img/phone/screen.png') ";
}

function showH(el) {
   el.style.background = "url('img/background_header.png') ";
}
function show7(el) {
    el.style.background = "url('img/down-bg.jpg') ";
}

function color1(el)
{
	el.style.background = "rgba(255, 255, 255, .2  )";
}

function color2(el)
{
	el.style.background = "#e74c3c";
}

document.getElementById("button").addEventListener("click", function() 
{
	let res = counter/2;
	if(isInteger(res))
	{
		hideh(imgOf);
		hideh(imgOff);
		hideh(imgOfff);
	}
	else
	{
		showS(imgOf);
		showH(imgOff);
		show7(imgOfff);
	}
	counter++;
});

let t;
let i;
let m;
let e;

document.getElementById("s1").addEventListener("mouseover",function()
{
	hide(b2);
	hide(b3);
	hide(b4);
	let color=0;
	l=setInterval(function(){
		if(isInteger(color/2))
		{
			color1(b1);
		}
		else
		{
			color2(b1);
		}
		color++;
	},100);
});

document.getElementById("s1").addEventListener("mouseout",function()
{
	show(b2);
	show(b3);
	show(b4);
	clearInterval(l);
	color1(b1);
});

document.getElementById("s2").addEventListener("mouseover",function()
{
	hide(b1);
	hide(b3);
	hide(b4);
	let color=0;
	i=setInterval(function(){
		if(isInteger(color/2))
		{
			color1(b2);
		}
		else
		{
			color2(b2);
		}
		color++;
	},100);
});

document.getElementById("s2").addEventListener("mouseout",function()
{
	show(b1);
	show(b3);
	show(b4);
	clearInterval(i);
	color1(b2);
});

document.getElementById("s3").addEventListener("mouseover",function()
{
	hide(b2);
	hide(b1);
	hide(b4);
	let color=0;
	m=setInterval(function(){
		if(isInteger(color/2))
		{
			color1(b3);
		}
		else
		{
			color2(b3);
		}
		color++;
	},100);
});

document.getElementById("s3").addEventListener("mouseout",function()
{
	show(b2);
	show(b1);
	show(b4);
	clearInterval(m);
	color1(b3);
});

document.getElementById("s4").addEventListener("mouseover",function()
{
	hide(b1);
	hide(b2);
	hide(b3);
	let color=0;
	e=setInterval(function(){
		if(isInteger(color/2))
		{
			color1(b4);
		}
		else
		{
			color2(b4);
		}
		color++;
	},100);
});

document.getElementById("s4").addEventListener("mouseout",function()
{
	show(b1);
	show(b2);
	show(b3);
	clearInterval();
	color1(b4);
});