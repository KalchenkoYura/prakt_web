var canvas = document.getElementById('canvas');
if (canvas.getContext) {
    var ctx = canvas.getContext('2d');
    for (var i = 0; i < 2; i++) {
        for (var j = 0; j < 5; j++) {
            ctx.beginPath();
            var x = 55 + j * 20;
            if (j == 0 || j == 2 || j == 4) { var y = 5 * 20; }
            else {
                var y = 6 * 20;
            }
            var radius = 20;
            var startAngle = 0;
            var endAngle = Math.PI + (Math.PI * 3) / 2;
            ctx.arc(x, y, radius, startAngle, endAngle, false);
            switch (j) {
                case 0: ctx.strokeStyle = "rgb(0,0,255)"; break;
                case 1: ctx.strokeStyle = "rgb(255,165,0)"; break;
                case 2: ctx.strokeStyle = "rgb(0,0,0)"; break;
                case 3: ctx.strokeStyle = "rgb(0,255,0)"; break;
                case 4: ctx.strokeStyle = "rgb(255,0,0)"; break;
            }
            ctx.stroke();
        }
    }
        function generateColor() {
            return '#' + Math.floor(Math.random() * 16777215).toString(16)
        };
        var timer = setInterval(function () {
            for (var i = 0; i < 2; i++) {
                for (var j = 0; j < 5; j++) {
                    ctx.beginPath();
                    var x = 55 + j * 20;
                    if (j == 0 || j == 2 || j == 4) { var y = 5 * 20; }
                    else {
                        var y = 6 * 20;
                    }
                    var radius = 20;
                    var startAngle = 0;
                    var endAngle = Math.PI + (Math.PI * 3) / 2;
                    ctx.arc(x, y, radius, startAngle, endAngle, false);
                    switch (j) {
                        case 0: ctx.strokeStyle = generateColor(); break;
                        case 1: ctx.strokeStyle = generateColor(); break;
                        case 2: ctx.strokeStyle = generateColor(); break;
                        case 3: ctx.strokeStyle = generateColor(); break;
                        case 4: ctx.strokeStyle = generateColor(); break;
                    }
                    ctx.stroke();
                }
            }
        }, 5000);
        
        
    }