<?php
header('Content-Type: text/html; charset=utf-8');
if(!empty($_POST['name']))
	$name=$_POST['name'];
else
	die("Вы забыли ввести имя");

if (!preg_match("/[A-Za-zА-Яа-яЁё]{2,10}\)+$/", $name)) 
{
	$name=$_POST['name'];
}
else{
	die("Данные в поле Имя введены не правильно!!!");
}

if(!empty($_POST['surname']))
	$surname=$_POST['surname'];
else
	die("Вы забыли ввести фамилию");

if (!preg_match("/[A-Za-zА-Яа-яЁё]{2,14}\)+$/", $surname)) 
{
	$surname=$_POST['surname'];
}
else{
	die("Данные в поле Фамиллия введены не правильно!!!");
}

if(!is_null($_POST['sex']))
	$sex=$_POST['sex'];
else
	$sex='undefined';

if(!empty($_POST['age']))
	$age=$_POST['age'];
else
	die("Вы забыли ввести возраст");

if (!preg_match("/^[0-9]+$\)+$/", $age)) 
{
	$age=$_POST['age'];
}
else{
	die("Данные в поле Возраст введены не правильно!!!");
}

if(!empty($_POST['email']))
	$email=$_POST['email'];
else
	die("Вы забыли ввести email");

if(!empty($_POST['login']))
	$login=$_POST['login'];
else
	die("Вы забыли ввести логин");

if (preg_match("/[A-Za-zА-Яа-яЁё]{4,}+$/", $login))
{
	$login=$_POST['login'];
}
else{
	die("<br/> Данные в поле Логин введены не правильно!!!");
}


if(!empty($_POST['pass']))
	$pass=$_POST['pass'];
else
	die("Вы забыли ввести пароль");

if (!preg_match("/(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}\)+$/", $pass)) 
{
	$pass=$_POST['pass'];
}
else{
	die("Данные в поле Пароль введены не правильно!!!");
}

$fname = $_FILES['avatar']['name'];
$types     = array(
	'.jpg',
	'.JPG',
	'.jpeg',
	'.bmp',
	'.png'
    );
$ext = substr($fname, strpos($fname, '.'), strlen($fname) - 1); 
$basepath = "image/";

if (!in_array($ext, $types)) {
	die('<p style="color:red;">Загружаемый файл не является картинкой</p>');
}

function genPass($length){
  $chars = 'abdefhiknrstyzABDEFGHKNQRSTYZ1234567890';
  $numChars = strlen($chars);
  $string = '';
  for ($i = 0; $i < $length; $i++) {
    $string .= substr($chars, rand(1, $numChars) - 1, 1);
  }
  return $string;
}

$fname = genPass(10) . $fname;

$avatar = $basepath . $fname;

move_uploaded_file($_FILES['avatar']['tmp_name'], $avatar);

include "connectdb.php";

$connect = new mysqli('localhost', 'root', '', 'prac16');

$connect->query("INSERT INTO prac16 VALUES ('$name', '$surname', '$sex', '$age', '$email', '$login', '$pass', '$avatar');");

if (mysqli_connect_error()) {
	die('Ошибка подключения (' . mysqli_connect_errno() . ') '. mysqli_connect_error());
} else {echo $name . " Вы зарегестрированы";}

$connect->close();