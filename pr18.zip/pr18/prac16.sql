-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Апр 10 2017 г., 22:36
-- Версия сервера: 10.1.21-MariaDB
-- Версия PHP: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `prac16`
--

-- --------------------------------------------------------

--
-- Структура таблицы `prac16`
--

CREATE TABLE `prac16` (
  `name` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `surname` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `sex` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `age` int(11) NOT NULL,
  `email` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `login` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `password` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `avatar` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `prac16`
--

INSERT INTO `prac16` (`name`, `surname`, `sex`, `age`, `email`, `login`, `password`, `avatar`) VALUES
('Yura', 'Kalchenko', 'man', 18, 'yura.kalchenko@mail.ru', 'aAaAa', 'aA123456', 'image/By4Q80HGs91d60b468.png'),
('Yura', 'Kalchenko', 'man', 18, 'yura.kalchenko@mail.ru', 'Kalchenko', 'aA123456', 'image/Dh3SA0HH951d60b468.png'),
('Yura', 'Kalchenko', 'man', 18, 'yura.kalchenko@mail.ru', 'Kalchenko', 'aA123456', 'image/Ty08a0G8aG1d60b468.png'),
('Yura', 'Kalchenko', 'man', 18, 'yura.kalchenko@mail.ru', 'Simon', 'aA123456', 'image/3AQNFSGn4EOY9AL7o-fbs.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
