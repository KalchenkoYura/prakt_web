<?php
if(!empty($_POST['login']))
	$login=$_POST['login'];
else
	die("Вы забыли ввести логин");

if(!empty($_POST['pass']))
	$pass=$_POST['pass'];
else
	die("Вы забыли ввести пароль");

$connect = new mysqli('localhost', 'root', '', 'prac16');

$connect->set_charset('utf8');

$rec = $connect->query("SELECT * FROM prac16 WHERE login = '".$login."';");

$data = $rec->fetch_assoc();

if($data['login'] == $login)
{
	$connect->query("SELECT * FROM prac16 WHERE login = '".$login."', password ='".$pass."';");
	include "lk.php";
}
else
{
    die("Наверное вы чтото ввели не правильно или не существует такого пользователь");
};

$connect->close();