let k=0;
function hide(el) 
{
    if (!el.hasAttribute('displayOld')) 
    {
        el.setAttribute("displayOld", el.style.display);
    }
  el.style.display = "none";
}

function show(el) {
    var old = el.getAttribute("displayOld");
  el.style.display = old || "";
}
      hide(document.getElementById("myProgress"));
      
      $("#video").on('play',function() {
        if(k==0){
        document.getElementById("video").pause();
        show(myProgress);
        let elem = document.getElementById("myBar");   
        let width = 0;
        $("#vid").css({'backgroundImage': 'url(img/screenVideo.png)'});
        hide(video);
          let id = setInterval(frame, 600);
          function frame() {
            if (width < 100) {
                width++; 
                elem.style.width = width + '%'; 
            } else {
              clearInterval(id);
              show(video);
              hide(myProgress);
              document.getElementById("video").play();
              k++;
            }
          }
          }
        });